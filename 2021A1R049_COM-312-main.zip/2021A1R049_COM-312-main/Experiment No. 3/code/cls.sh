echo "Program: $0"
echo "The number of arguments entered are: $#"
echo "The arguments are: $*"
grep "$1" $2
echo "JOB FINISH"

