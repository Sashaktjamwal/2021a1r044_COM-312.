#include <stdio.h>
#include <string.h>
int main()
{
	char a[100]="Welcome to Operating System Lab";
	int length;
 	length = strlen(a);
	printf("Length of the string = %d\n", length);
	return 0;
}
