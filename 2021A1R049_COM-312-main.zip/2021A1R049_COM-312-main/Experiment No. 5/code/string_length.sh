str="WELCOME to Operating System lab"
echo "The total no of char in the string are: ${#str}"

