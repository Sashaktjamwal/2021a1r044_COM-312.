echo "Enter the name of the user: "
read username
last $username
